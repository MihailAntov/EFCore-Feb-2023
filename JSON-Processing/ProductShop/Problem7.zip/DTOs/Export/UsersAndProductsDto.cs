﻿

namespace ProductShop.DTOs.Export
{
    public class UsersAndProductsDto
    {
        int usersCount { get; set; }
        
    }
}
