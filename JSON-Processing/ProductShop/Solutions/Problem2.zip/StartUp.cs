﻿using Newtonsoft.Json;

using ProductShop.Data;
using ProductShop.Models;
using ProductShop.DTOs.Import;
namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            ProductShopContext context = new ProductShopContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            //problem 1
            string usersAsJson = File.ReadAllText("../../../Datasets/users.json");
            Console.WriteLine(ImportUsers(context, usersAsJson));

            //problem2
            string productsAsJson = File.ReadAllText("../../../Datasets/products.json");
                global::System.Console.WriteLine(ImportProducts(context, productsAsJson));


        }
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            var products = JsonConvert.DeserializeObject<List<ProductDto>>(inputJson)
                .Select(p=>new Product()
                {
                    Name = p.Name,
                    Price = p.Price,
                    SellerId = p.SellerId,
                    BuyerId = p.BuyerId,
                });

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var users = JsonConvert.DeserializeObject<UserDto[]>(inputJson)
                .Select(u => new User
                {
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Age = u.Age
                });
            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }
    }
}