﻿using Newtonsoft.Json;

using ProductShop.Data;
using ProductShop.Models;
using ProductShop.DTOs.Import;
namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            string usersAsJson = File.ReadAllText("../../../Datasets/users.json");
            
            using (ProductShopContext context = new ProductShopContext())
            {
                Console.WriteLine(ImportUsers(context,usersAsJson));
            }
            
        }

        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var users = JsonConvert.DeserializeObject<UserDto[]>(inputJson)
                .Select(u => new User
                {
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Age = u.Age
                });
             context.Users.AddRange(users);
             context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }
    }
}