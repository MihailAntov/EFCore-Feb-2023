﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace ProductShop.DTOs.Import
{
    public class UserDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? Age { get; set; }
    }
}
