﻿using CarDealer.DTOs.Export;
using CarDealer.Models;

using AutoMapper;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            
        }
    }
}
