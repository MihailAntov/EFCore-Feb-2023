﻿using Newtonsoft.Json;

using CarDealer.Models;
using CarDealer.Data;
using CarDealer.DTOs.Import;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using (CarDealerContext context = new CarDealerContext())
            {

                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();


                //problem 9
                string suppliersAsJson = File.ReadAllText("../../../Datasets/suppliers.json");
                Console.WriteLine(ImportSuppliers(context, suppliersAsJson));

                string partsAsJson = File.ReadAllText("../../../Datasets/parts.json");
                Console.WriteLine(ImportParts(context, partsAsJson));
            }
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliers = JsonConvert.DeserializeObject<SupplierDto[]>(inputJson)
                .Select(u => new Supplier
                {
                    Name = u.Name,
                    IsImporter = u.IsImporter,
                    
                });
            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var parts = JsonConvert.DeserializeObject<PartDto[]>(inputJson)
                .Select(p => new Part()
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .Where(p => context.Suppliers.Any(s => s.Id == p.SupplierId));



            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}.";
        }


    }
}