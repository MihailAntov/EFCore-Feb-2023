﻿using Newtonsoft.Json;

namespace CarDealer.DTOs.Export
{
    public class CustomerBoughtCarOutputDto
    {

    }
}
