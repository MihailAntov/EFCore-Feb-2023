﻿using Newtonsoft.Json;

using CarDealer.Models;
using CarDealer.Data;
using CarDealer.DTOs.Import;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using (CarDealerContext context = new CarDealerContext())
            {

                //context.Database.EnsureDeleted();
                //context.Database.EnsureCreated();


                // problem 9
                //string suppliersAsJson = File.ReadAllText("../../../Datasets/suppliers.json");
                //Console.WriteLine(ImportSuppliers(context, suppliersAsJson));

                //problem 10
                //string partsAsJson = File.ReadAllText("../../../Datasets/parts.json");
                //Console.WriteLine(ImportParts(context, partsAsJson));

                //problem 11
                //string carsAsJson = File.ReadAllText("../../../Datasets/cars.json");
                //Console.WriteLine(ImportCars(context, carsAsJson));

                //problem 12
                //string customersAsJson = File.ReadAllText("../../../Datasets/customers.json");
                //Console.WriteLine(ImportCustomers(context, customersAsJson));

                //problem 13
                //string salesAsJson = File.ReadAllText("../../../Datasets/sales.json");
                //Console.WriteLine(ImportSales(context, salesAsJson));

                //problem 14
                Console.WriteLine(GetOrderedCustomers(context));

            }
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliers = JsonConvert.DeserializeObject<SupplierDto[]>(inputJson)
                .Select(u => new Supplier
                {
                    Name = u.Name,
                    IsImporter = u.IsImporter,

                });
            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var parts = JsonConvert.DeserializeObject<PartDto[]>(inputJson)
                .Select(p => new Part()
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .Where(p => context.Suppliers.Any(s => s.Id == p.SupplierId));



            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            List<Car> cars = new List<Car>();
            List<PartCar> partsCars = new List<PartCar>();
            
            var carDtos = JsonConvert.DeserializeObject<CarDto[]>(inputJson);

            foreach (CarDto carDto in carDtos)
            {
                Car car = new Car()
                {
                    Make = carDto.Make,
                    Model = carDto.Model,
                    TravelledDistance = carDto.TraveledDistance
                   
                    
                };
                cars.Add(car);

                foreach (int partId in carDto.PartsId.Distinct())
                {
                    partsCars.Add(new PartCar()
                    {
                        PartId = partId,
                        Car = car
                    });
                }
            }

            context.Cars.AddRange(cars);
            context.PartsCars.AddRange(partsCars);

            context.SaveChanges();
            return $"Successfully imported {cars.Count()}.";
        }


        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            List<Customer> customers = new List<Customer>();
            var customerDtos = JsonConvert.DeserializeObject<CustomerDto[]>(inputJson);

            foreach(CustomerDto c in customerDtos)
            {
                Customer customer = new Customer()
                {
                    Name = c.Name,
                    BirthDate = c.BirthDate,
                    IsYoungDriver = c.IsYoungDriver
                };
                customers.Add(customer);
            }

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count}.";
        }

        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            List<Sale> sales = new List<Sale>();

            var saleDtos = JsonConvert.DeserializeObject<SaleDto[]>(inputJson);

            foreach(SaleDto s in saleDtos)
            {
                Sale sale = new Sale()
                {
                    Discount = s.Discount,
                    CarId = s.CarId,
                    CustomerId = s.CustomerId
                };
                sales.Add(sale);
            }

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count}.";
        }

        public static string GetOrderedCustomers(CarDealerContext context)
        {
            var result = context.Customers
                .OrderBy(c => c.BirthDate)
                .ThenBy(c => c.IsYoungDriver)
                .Select(c => new
                {
                    Name = c.Name,
                    BirthDate = c.BirthDate.ToString("dd/MM/yyyy"),
                    IsYoungDriver = c.IsYoungDriver
                }); 

            return JsonConvert.SerializeObject(result,Formatting.Indented);
        }

    }
}