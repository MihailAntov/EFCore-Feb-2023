﻿using Newtonsoft.Json;

using CarDealer.Models;
using CarDealer.Data;
using CarDealer.DTOs.Import;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using (CarDealerContext context = new CarDealerContext())
            {
                //context.Database.EnsureCreated();
                
                
                //problem 9
                string suppliersAsJson = File.ReadAllText("../../../Datasets/suppliers.json");
                Console.WriteLine(ImportSuppliers(context, suppliersAsJson));
            }
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliers = JsonConvert.DeserializeObject<SupplierDto[]>(inputJson)
                .Select(u => new Supplier
                {
                    Name = u.Name,
                    IsImporter = u.IsImporter,
                    
                });
            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}.";
        }




    }
}