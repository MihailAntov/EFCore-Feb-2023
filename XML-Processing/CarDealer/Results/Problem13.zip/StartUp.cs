﻿using CarDealer.Data;

using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using (CarDealerContext context = new CarDealerContext())
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();

                string suppliersXml = File.ReadAllText("../../../Datasets/suppliers.xml");
                Console.WriteLine(ImportSuppliers(context, suppliersXml));

                string partsXml = File.ReadAllText("../../../Datasets/parts.xml");
                Console.WriteLine(ImportParts(context, partsXml));

                string carsXml = File.ReadAllText("../../../Datasets/cars.xml");
                Console.WriteLine(ImportCars(context, carsXml));

                string customersXml = File.ReadAllText("../../../Datasets/customers.xml");
                Console.WriteLine(ImportCustomers(context, customersXml));

                string salesXml = File.ReadAllText("../../../Datasets/sales.xml");
                Console.WriteLine(ImportSales(context, salesXml));

            }
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            TextReader reader = new StringReader(inputXml);

            XDocument xDocument = XDocument.Load(reader);

            ICollection<Supplier> suppliers = new HashSet<Supplier>();

            foreach (var supplier in xDocument.Root.Elements())
            {
                suppliers.Add(new Supplier()
                {
                    Name = supplier.Element("name").Value,
                    IsImporter = bool.Parse(supplier.Element("isImporter").Value)

                });
            }

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";

        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            TextReader textReader = new StringReader(inputXml);
            XDocument xDocument = XDocument.Load(textReader);
            ICollection<Part> parts = new HashSet<Part>();

            ICollection<int> suppliers = context.Suppliers
                .Select(s => s.Id)
                .ToHashSet();

            foreach (var part in xDocument.Root.Elements())
            {
                int supplierId = int.Parse(part.Element("supplierId").Value);
                if (!suppliers.Contains(supplierId))
                {
                    continue;
                }
                string name = part.Element("name").Value;
                decimal price = decimal.Parse(part.Element("price").Value);
                int quantity = int.Parse(part.Element("quantity").Value);


                parts.Add(new Part()
                {
                    Name = name,
                    Price = price,
                    Quantity = quantity,
                    SupplierId = supplierId
                });


            }

            context.Parts.AddRange(parts.Where(p => suppliers.Contains(p.SupplierId)));
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";

        }

        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            TextReader textReader = new StringReader(inputXml);
            XDocument carsXml = XDocument.Load(textReader);
            List<int> partIds = context.Parts.Select(p => p.Id).ToList();

            ICollection<Car> cars = new HashSet<Car>();

            foreach(var car in carsXml.Root.Elements())
            {
                string make = car.Element("make").Value;
                string model = car.Element("model").Value;
                int travelDistance = int.Parse(car.Element("traveledDistance").Value);

                var inputPartIds = car.Element("parts").Elements();
                List<int> validPartIds = new List<int>();
                foreach (var partId in inputPartIds)
                {
                    XAttribute attr = partId.Attribute("id");
                    int value = int.Parse(attr.Value);
                    if(partIds.Contains(value) && !validPartIds.Contains(value))
                    {
                        validPartIds.Add(value);
                    }
                }


                

                cars.Add(new Car()
                {
                    Make = make,
                    Model = model,
                    TravelledDistance = travelDistance,
                    PartsCars = validPartIds.Select(id => new PartCar()
                    {
                        PartId = id
                    })
                    .ToList()
                });

                
            }
            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}";

        }

        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            TextReader reader = new StringReader(inputXml);
            XDocument doc = XDocument.Load(reader);
            ICollection<Customer> customers = new HashSet<Customer>();

            foreach(var customer in doc.Root.Elements())
            {
                string name = customer.Element("name").Value;
                DateTime birthDate = DateTime.Parse(customer.Element("birthDate").Value);
                bool isYoungDriver = bool.Parse(customer.Element("isYoungDriver").Value);

                customers.Add(new Customer()
                {
                    Name = name,
                    BirthDate = birthDate,
                    IsYoungDriver = isYoungDriver
                });
            }

            context.Customers.AddRange(customers);

            context.SaveChanges();



            return $"Successfully imported {customers.Count}";
        }


        public static string ImportSales(CarDealerContext context, string inputXml)
        {
            TextReader reader = new StringReader(inputXml);
            XDocument doc = XDocument.Load(reader);
            HashSet<int> existingCarIds = context
                .Cars
                .AsNoTracking()
                .Select(c => c.Id)
                .ToHashSet();
            ICollection<Sale> sales = new HashSet<Sale>();
            foreach(var saleXml in doc.Root.Elements())
            {
                int carId = int.Parse(saleXml.Element("carId").Value);
                if(!existingCarIds.Contains(carId))
                {
                    continue;
                }

                int customerId = int.Parse(saleXml.Element("customerId").Value);
                int discount = int.Parse(saleXml.Element("discount").Value);

                Sale sale = new Sale()
                {
                    CarId = carId,
                    CustomerId = customerId,
                    Discount = discount
                };
                sales.Add(sale);
            }

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count}";
        }


    }
}