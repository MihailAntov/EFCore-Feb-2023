﻿using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;
using AutoMapper.QueryableExtensions;

using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using AutoMapper;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using (ProductShopContext context = new ProductShopContext())
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();

                //problem 1
                string usersXml = "../../../Datasets/users.xml";
                Console.WriteLine(ImportUsers(context, usersXml));

                //problem2
                string productsXml = File.ReadAllText("../../../Datasets/products.xml");
                Console.WriteLine(ImportProducts(context, productsXml));

                string categoriesXml = "../../../Datasets/categories.xml";
                //Console.WriteLine(ImportCategories(context, categoriesXml));

            }
        }
        


        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            

            


            XDocument usersXml = XDocument.Load(inputXml);
            ICollection<User> users = new HashSet<User>();
            foreach (var user in usersXml.Root.Elements())
            {
                string firstName = user.Element("firstName").Value;
                string lastName = user.Element("lastName").Value;
                int age = int.Parse(user.Element("age").Value);

                users.Add(new User()
                {
                    FirstName = firstName,
                    LastName = lastName,
                    Age = age
                });
            }

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count}";


        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            StringReader reader = new StringReader(inputXml);
            
            XDocument productsXml = XDocument.Load(reader);

            ICollection<Product> products = new HashSet<Product>();

            foreach (var product in productsXml.Root.Elements())
            {
                string name = product.Element("name").Value;
                decimal price = decimal.Parse(product.Element("price").Value);
                int sellerId = int.Parse(product.Element("sellerId").Value);
                int? buyerId = null;
                if (product.Element("buyerId") != null)
                {
                    buyerId = int.Parse(product.Element("buyerId").Value);
                }


                products.Add(new Product()
                {
                    Name = name,
                    Price = price,
                    SellerId = sellerId,
                    BuyerId = buyerId
                });
            }

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count}";


        }

        public static string ImportCategories(ProductShopContext context, string inputXml)
        {

            return " ";
        }
    }
}