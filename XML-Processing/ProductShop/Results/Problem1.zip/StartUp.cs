﻿using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;
using AutoMapper.QueryableExtensions;

using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using AutoMapper;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using (ProductShopContext context = new ProductShopContext())
            {
                //problem 1
                string usersXml = "../../../Datasets/users.xml";
                ImportUsers(context, usersXml);

            }
        }



        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(UserDto));

            XDocument usersXml = XDocument.Load(inputXml);
            ICollection<User> users = new HashSet<User>();
            foreach(var user in usersXml.Root.Elements())
            {
                string firstName = user.Element("firstName").Value;
                string lastName = user.Element("lastName").Value;
                int age = int.Parse(user.Element("age").Value);

                users.Add(new User() {
                    FirstName = firstName,
                    LastName = lastName,
                    Age = age
                });
            }

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count}";


        }
    }
}