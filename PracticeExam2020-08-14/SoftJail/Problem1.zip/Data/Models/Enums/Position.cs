﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftJail.Data.Models.Enums
{
    public enum Position
    {
        Overseer,
        Guard,
        Watcher,
        Labour
    }
}
