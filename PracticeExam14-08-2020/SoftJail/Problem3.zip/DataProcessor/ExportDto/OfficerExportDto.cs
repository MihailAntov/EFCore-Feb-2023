﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftJail.DataProcessor.ExportDto
{
    public class OfficerExportDto
    {
        public string OfficerName { get; set; }
        public string Department { get; set; }
    }
}
