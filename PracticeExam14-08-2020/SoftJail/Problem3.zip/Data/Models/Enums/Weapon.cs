﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife,
        FlashPulse,
        ChainRifle,
        Pistol,
        Sniper
    }
}
