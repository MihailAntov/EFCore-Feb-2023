﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUni;

public class StartUp
{
    
    public static void Main(string[] args)
    {
        using (SoftUniContext context = new SoftUniContext())
        {
            //GetEmployeesFullInformation(context);
            //Console.WriteLine(GetEmployeesWithSalaryOver50000(context));
            //Console.WriteLine(GetEmployeesFromResearchAndDevelopment(context));
            //Console.WriteLine(AddNewAddressToEmployee(context));
            // -- 
            //Console.WriteLine(GetEmployeesInPeriod(context));
            //--
            Console.WriteLine(GetAddressesByTown(context));
        }
    }

    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        
        
            List<Employee> employees = context.Employees.OrderBy(e => e.EmployeeId).ToList();
            StringBuilder str = new StringBuilder();
            foreach ( Employee e in employees )
            {
                str.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:F2}");
            }
            return str.ToString().TrimEnd();
              
    }

    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
    {
        List<Employee> employees = context.Employees
            .Where(e => e.Salary > 50000)
            .OrderBy(e => e.FirstName)
            .ToList();
        StringBuilder str = new StringBuilder();
        foreach (Employee e in employees)
        {
            str.AppendLine($"{e.FirstName} - {e.Salary:f2}");
        }
        return str.ToString().TrimEnd();

    }
    public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
    {
        //int departmentId = context.Departments
        //    .FirstOrDefault(d => d.Name == "Research and Development")
        //    .DepartmentId;

        //var employees = context.Employees
        //    .Where(d => d.DepartmentId == departmentId)
        //    .Select(e=> new {Name = e.FirstName, DepartmentName = e.Department.Name, Salary = e.Salary})
        //    .ToList();

        var employees = context.Employees
            .Where(d => d.Department.Name == "Research and Development")
            .Select(e=> new {FirstName = e.FirstName,LastName = e.LastName, DepartmentName = e.Department.Name, Salary = e.Salary})
            .ToList();
        StringBuilder str = new StringBuilder();
        foreach (var e in employees)
        {
            str.AppendLine($"{e.FirstName} {e.LastName} from {e.DepartmentName} - ${e.Salary:f2}");
        }
        return str.ToString().TrimEnd();


    }
    public static string AddNewAddressToEmployee(SoftUniContext context)
    {
        Address newAddress = new Address()
        {
            AddressText = "Vitoshka 15",
            TownId = 4
        };

        Employee? nakov = context.Employees
            .Where(e => e.LastName == "Nakov")
            .FirstOrDefault();

        if(nakov != null)
        {
            nakov.Address = newAddress;
        }

        context.SaveChanges();

        List<String> addresses = context.Employees
            .OrderByDescending(e => e.AddressId)
            .Take(10)
            .Select(e => e.Address.AddressText)
            .ToList();

        StringBuilder str = new StringBuilder();
        foreach(string address in addresses)
        {
            str.AppendLine(address);
        }

        return str.ToString().TrimEnd();

        
    }
    public static string GetEmployeesInPeriod(SoftUniContext context)
    {
        throw new NotImplementedException();
    }

    public static string GetAddressesByTown(SoftUniContext context)
    {
        var addresses = context.Addresses
            .Select(a => new
            {
                Text = a.AddressText,
                Town = a.Town.Name,
                Count = a.Employees.Count()
            })
            .OrderByDescending(e => e.Count)
            .ThenBy(e => e.Town)
            .ThenBy(e => e.Text)
            .Take(10);

        StringBuilder str = new StringBuilder();
        foreach(var a in addresses)
        {
            str.AppendLine($"{a.Text}, {a.Town} - {a.Count} employees");
        }

        return str.ToString().TrimEnd();
    }


}

