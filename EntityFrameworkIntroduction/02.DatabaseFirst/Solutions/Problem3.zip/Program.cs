﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUni;

public class StartUp
{
    
    public static void Main(string[] args)
    {
        using (SoftUniContext context = new SoftUniContext())
        {
            GetEmployeesFullInformation(context);
        }
    }

    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        
        
            List<Employee> employees = context.Employees.OrderBy(e => e.EmployeeId).ToList();
            StringBuilder str = new StringBuilder();
            foreach ( Employee e in employees )
            {
                str.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:F2}");
            }
            return str.ToString().TrimEnd();
              
    } 
}
