﻿namespace Trucks.DataProcessor
{
    using Data;
    using System.Xml.Serialization;

    

    public class Serializer
    {
        public static string ExportDespatchersWithTheirTrucks(TrucksContext context)
        {
            throw new NotImplementedException();
        }

        public static string ExportClientsWithMostTrucks(TrucksContext context, int capacity)
        {
            throw new NotImplementedException();
        }
    }
}
