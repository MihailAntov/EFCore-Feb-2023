﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Artillery.Data.Models.Enums
{
    public enum GunType
    {
        Howitzer,
        Mortar,
        FieldGun,
        AntiAircraftGun,
        MountainGun,
        AntiTankGun
    }
}
