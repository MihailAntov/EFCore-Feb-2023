﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=.;Database=BookShop;Integrated Security=True;";
    }
}
